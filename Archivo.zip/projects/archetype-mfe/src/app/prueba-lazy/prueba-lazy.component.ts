import { Component } from '@angular/core';

@Component({
  selector: 'app-prueba-lazy',
  imports: [],
  templateUrl: './prueba-lazy.component.html',
  styleUrl: './prueba-lazy.component.scss'
})
export class PruebaLazyComponent {

}
